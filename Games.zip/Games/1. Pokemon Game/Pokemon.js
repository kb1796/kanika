function loadImages(){
    
    playerImage = new Image;
    playerImage.src = "assets/pika.png";
    
    enemyImage = new Image;
    enemyImage.src = "assets/gengar.png";

    goalImage = new Image;
    goalImage.src = "assets/ball.png";
    
    var enemyNames = ["drowsy","gengar","meow"];
    
    enemyImages = [];
    
    for(i=0;i<enemyNames.length;i++){
        enemyImg = new Image;
        enemyImg.src = "assets/" + enemyNames[i] + ".png";
        enemyImages.push(enemyImg);
    }
}

function init(level=1){
    console.log("In Init");
    
    canvas=document.getElementById('mycanvas');
    pen=canvas.getContext('2d');
    
    W=canvas.width;
    H=canvas.height;
    
    GAME_OVER = false;
    score = 0;
    
    player={
        x:0,
        y:H/2,
        w:60,
        h:60,
        speedX:0
    }
    
    goal={
        x:W-60,
        y:H/2,
        w:60,
        h:60
    }
    
    enemy={
        x:200,
        y:300,
        w:60,
        h:60,
        speedX:5,
        speedY:5
    }
    
    enemy2={
        x:400,
        y:400,
        w:60,
        h:60,
        speedX:5,
        speedY:-5
    }
    
    enemy3={
        x:600,
        y:400,
        w:60,
        h:60,
        speedX:5,
        speedY:3
    }
    
    enemies = [];
    enemies.push(enemy);
    enemies.push(enemy2);
    enemies.push(enemy3);
    
    function movePlayer(){
        player.speedX=5;
    }
    
    function stopPlayer(){
        player.speedX=0;
    }
    
    canvas.addEventListener('mousedown',movePlayer);
    canvas.addEventListener('mouseup',stopPlayer);
    
}

function isColliding(r1,r2){
    var firstCond = Math.abs(r1.x-r2.x) <= r1.w-10;
    var secondCond = Math.abs(r1.y-r2.y) <= r1.h-10;
    
    return firstCond && secondCond;
}


function draw(){
    console.log("In Draw");
    
    pen.clearRect(0,0,W,H);
    
    //pen.fillStyle = "red";
    //pen.fillRect(enemy.x,enemy.y,enemy.w,enemy.h);
    for(var i=0;i<level;i++){
    pen.drawImage(enemyImages[i],enemies[i].x,enemies[i].y,enemies[i].w,enemies[i].h);
    }
    
    //pen.fillStyle = "green";
    //pen.fillRect(goal.x,goal.y,goal.w,goal.h);
    pen.drawImage(goalImage,goal.x,goal.y,goal.w,goal.h);
    
    //pen.fillStyle = "aqua";
    //pen.fillRect(player.x,player.y,player.w,player.h);
    pen.drawImage(playerImage,player.x,player.y,player.w,player.h);
    
    pen.font = "20px Arial";
    pen.fillStyle = "white";
    pen.fillText("Score : "+score,15,30);
}

function update(){
    console.log("In Update");
    
    for(var i=0;i<enemies.length;i++){
        enemies[i].y += enemies[i].speedY;
    }
    
    for(var i=0;i<enemies.length;i++){
    if(enemies[i].y >= H - enemies[i].h || enemies[i].y<=0){
      enemies[i].speedY *= -1;
     }
    }
    
    player.x += player.speedX;
    
    score = Math.round((player.x)/12);
    
    for(var i=0;i<level;i++){
    if(isColliding(player,enemies[i])){
        console.log("Game Over");
        alert("Game Over");
        GAME_OVER = true;
     }
    
    else if(isColliding(player,goal)){
        console.log("Level Cleared");
        
        alert("Congrats! You cleared the level");
        level=level+1;
        GAME_OVER = true;
        restartGame(level+1);
    }
  }
}

function gameLoop(){
    draw();
    update();
    
    if(GAME_OVER == false){
    window.requestAnimationFrame(gameLoop);
    }
    
    else{
        choice = prompt("Do you want to play again?");
        if(choice=="yes" || choice=="YES" || choice=="Yes"){
            restartGame(level+1);
        }
        else{
            alert("Thank you for playing");
        }
    }
}

loadImages();

function restartGame(level){
    init(level);
    gameLoop();
}

restartGame(level=1);