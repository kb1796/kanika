function loadImages(){
    enemyImg = new Image;
    playerImg = new Image;
    
    enemyImg.src = "Images/enemy.png";
    playerImg.src = "Images/player.png";
}

function init(){
    canvas = document.getElementById("mycanvas");
    pen = canvas.getContext('2d');
    W = canvas.width;
    H = canvas.height;
    score = 0;
    
    player = {
        x:W/2-50,
        y:H-80,
        w:80,
        h:80,
        speedX:0,
        
        bullets : [],
        
        shoot : function(){
        var b = new bullet(this.x+35,this.y,10);
        this.bullets.push(b);
    }
    };
    
    function movePlayer(e){
        if(e.key == "ArrowRight"){
        player.speedX = 10;
        }
            else if(e.key == "ArrowLeft"){
            player.speedX = -10;
            }
            else if(e.key == " "){
                console.log("Shooting");
                player.shoot();
            }
        }
    
    function stopPlayer(e){
        if(e.key == "ArrowRight" || e.key == "ArrowLeft"){
            player.speedX = 0;
        }
    }
    document.addEventListener('keydown',movePlayer);
    document.addEventListener('keyup',stopPlayer);
    
    enemies = [];
    
    function createEnemy(){
        var x = Math.round(Math.random()*W-50);
        var y = Math.round(Math.random()*200);
        var speed = Math.round(Math.random()*3)+2;
        
        var myEnemy = new enemy(x,y,speed);
        enemies.push(myEnemy);   
    }
    
    setInterval(createEnemy,1000);
    }


function draw(){
    pen.clearRect(0,0,W,H);
    
    pen.drawImage(playerImg,player.x,player.y,player.w,player.h);
    
    for(var i=0;i<player.bullets.length;i++){
        player.bullets[i].draw();
    }
    
    for(var i=0;i<enemies.length;i++){
        enemies[i].draw();
    }
}

function update(){
    player.x += player.speedX;
    
    for(var i=0;i<player.bullets.length;i++){
        player.bullets[i].update();
    }
    
    for(var i=0;i<enemies.length;i++){
        enemies[i].update();
    }
}

function bullet(x,y,speed){
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.w = 10;
    this.h = 20;
    this.color = "green";
    
    this.draw = function(){
        pen.fillStyle = this.color;
        pen.fillRect(this.x,this.y,this.w,this.h);
    }
    
    this.update = function(){
        this.y -= this.speed;
    }
}

function enemy(x,y,speed){
    this.x = x;
    this.y = y;
    this.w = 50;
    this.h = 50;
    this.speedY = speed-2;
    this.speedX = 5;
    
    this.draw = function(){
        pen.drawImage(enemyImg,this.x,this.y,this.w,this.h);
        
    }
    
    this.update = function(){
        this.y += this.speedY;
        this.x += this.speedX;
        if(this.x >= W-50 || this.x <=0){
            this.speedX *= -1;
        }
    }
}

function isColliding(enemy,bullet){
    var firstCond = Math.abs(bullet.x-enemy.x) <= enemy.w;
    var secondCond = Math.abs(bullet.y-enemy.y) <= enemy.h;
    
    if(firstCond==true && secondCond==true){
    console.log("Enemy got hit");
    
        for(var i=0;i<enemies.length;i--){
        enemies[i].destroy;
        }
    }
}

function gameLoop(){
    draw();
    update();
    window.requestAnimationFrame(gameLoop);
}

function startGame(){
    loadImages();
    init();
    gameLoop();
}
startGame();